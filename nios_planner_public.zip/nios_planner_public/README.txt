NIOS Class 12 Elite Planner - Public Static Hosting

Upload this folder's contents to a static hosting provider such as Netlify Drop or Vercel.
The entry file is index.html.

Important: progress currently uses browser localStorage. The same public URL opens on every device, but progress is stored separately in each browser/device. Cross-device progress sync requires a hosted backend and a private user account/database; do not use a shared public progress file.
